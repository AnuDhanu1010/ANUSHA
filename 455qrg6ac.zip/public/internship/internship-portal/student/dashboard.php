<?php
session_start();
require_once "../config/database.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] != "student") {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION["user_id"];

$stmt = $conn->prepare("SELECT id FROM students WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();
$student_id = $student["id"];

$count = $conn->prepare("SELECT COUNT(*) AS total FROM applications WHERE student_id = ?");
$count->bind_param("i", $student_id);
$count->execute();
$total_applications = $count->get_result()->fetch_assoc()["total"];

$count2 = $conn->query("SELECT COUNT(*) AS total FROM internships WHERE status = 'Open'");
$open_internships = $count2->fetch_assoc()["total"];

$count3 = $conn->prepare("SELECT COUNT(*) AS total FROM applications WHERE student_id = ? AND status = 'Selected'");
$count3->bind_param("i", $student_id);
$count3->execute();
$selected = $count3->get_result()->fetch_assoc()["total"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard - Anu InternBridge</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <nav class="navbar">
        <a class="brand" href="dashboard.php">Anu Intern<span>Bridge</span></a>
        <div class="nav-links">
            <a href="profile.php">Profile</a>
            <a href="internships.php">Internships</a>
            <a href="applications.php">Applications</a>
            <a href="../logout.php">Logout</a>
        </div>
    </nav>

    <main class="container">
        <div class="page-heading">
            <div>
                <div class="badge">STUDENT DASHBOARD</div>
                <h1>Welcome, <?php echo htmlspecialchars($_SESSION["name"]); ?></h1>
                <p>Manage your profile and internship applications from one place.</p>
            </div>
            <a class="button primary" href="internships.php">Find Internships</a>
        </div>

        <section class="stats">
            <div class="stat-card"><span>Applications</span><strong><?php echo $total_applications; ?></strong></div>
            <div class="stat-card"><span>Open Internships</span><strong><?php echo $open_internships; ?></strong></div>
            <div class="stat-card"><span>Selected</span><strong><?php echo $selected; ?></strong></div>
        </section>

        <section class="panel">
            <h2>Application workflow</h2>
            <div class="workflow">
                <span class="current">Applied</span><span>→</span>
                <span>Under Review</span><span>→</span>
                <span>Shortlisted</span><span>→</span>
                <span>Interview</span><span>→</span>
                <span>Selected / Rejected</span>
            </div>
        </section>
    </main>
</body>
</html>
