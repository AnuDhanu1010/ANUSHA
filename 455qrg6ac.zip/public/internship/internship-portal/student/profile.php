<?php
session_start();
require_once "../config/database.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] != "student") {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION["user_id"];
$message = "";

$stmt = $conn->prepare(
    "SELECT users.name, users.email, students.phone, students.college, students.course,
    students.skills, students.resume FROM users
    JOIN students ON users.id = students.user_id
    WHERE users.id = ?"
);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$profile = $stmt->get_result()->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $phone = trim($_POST["phone"]);
    $college = trim($_POST["college"]);
    $course = trim($_POST["course"]);
    $skills = trim($_POST["skills"]);
    $resume = $profile["resume"];

    if (isset($_FILES["resume"]) && $_FILES["resume"]["error"] == 0) {
        $allowed = ["pdf", "doc", "docx"];
        $extension = strtolower(pathinfo($_FILES["resume"]["name"], PATHINFO_EXTENSION));

        if (in_array($extension, $allowed)) {
            if (!is_dir("../uploads")) {
                mkdir("../uploads", 0777, true);
            }

            $resume = time() . "_" . basename($_FILES["resume"]["name"]);
            move_uploaded_file($_FILES["resume"]["tmp_name"], "../uploads/" . $resume);
        }
    }

    $update = $conn->prepare(
        "UPDATE students SET phone = ?, college = ?, course = ?, skills = ?, resume = ?
        WHERE user_id = ?"
    );
    $update->bind_param("sssssi", $phone, $college, $course, $skills, $resume, $user_id);
    $update->execute();

    $message = "Profile updated successfully.";

    $stmt->execute();
    $profile = $stmt->get_result()->fetch_assoc();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - Anu InternBridge</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <nav class="navbar">
        <a class="brand" href="dashboard.php">Anu Intern<span>Bridge</span></a>
        <div class="nav-links">
            <a href="dashboard.php">Dashboard</a>
            <a href="internships.php">Internships</a>
            <a href="applications.php">Applications</a>
            <a href="../logout.php">Logout</a>
        </div>
    </nav>

    <main class="container narrow">
        <div class="page-heading">
            <div><div class="badge">MY PROFILE</div><h1>Student Profile</h1><p>Keep your information ready for internship applications.</p></div>
        </div>

        <?php if ($message != ""): ?>
            <div class="alert success"><?php echo $message; ?></div>
        <?php endif; ?>

        <form class="panel form-grid" method="POST" enctype="multipart/form-data">
            <div>
                <label>Name</label>
                <input type="text" value="<?php echo htmlspecialchars($profile["name"]); ?>" disabled>
            </div>

            <div>
                <label>Email</label>
                <input type="email" value="<?php echo htmlspecialchars($profile["email"]); ?>" disabled>
            </div>

            <div>
                <label>Phone</label>
                <input type="text" name="phone" value="<?php echo htmlspecialchars($profile["phone"] ?? ""); ?>" placeholder="Phone number">
            </div>

            <div>
                <label>College</label>
                <input type="text" name="college" value="<?php echo htmlspecialchars($profile["college"] ?? ""); ?>" placeholder="College name">
            </div>

            <div>
                <label>Course</label>
                <input type="text" name="course" value="<?php echo htmlspecialchars($profile["course"] ?? ""); ?>" placeholder="Course / Department">
            </div>

            <div>
                <label>Skills</label>
                <input type="text" name="skills" value="<?php echo htmlspecialchars($profile["skills"] ?? ""); ?>" placeholder="PHP, MySQL, HTML, CSS">
            </div>

            <div class="full-width">
                <label>Resume</label>
                <input type="file" name="resume" accept=".pdf,.doc,.docx">
            </div>

            <div class="full-width">
                <button class="button primary" type="submit">Save Profile</button>
            </div>
        </form>
    </main>
</body>
</html>
