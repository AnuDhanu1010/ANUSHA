<?php
session_start();
require_once "../config/database.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] != "student") {
    header("Location: ../login.php");
    exit();
}

$internship_id = intval($_GET["id"] ?? 0);
$user_id = $_SESSION["user_id"];

$student_stmt = $conn->prepare("SELECT id FROM students WHERE user_id = ?");
$student_stmt->bind_param("i", $user_id);
$student_stmt->execute();
$student = $student_stmt->get_result()->fetch_assoc();
$student_id = $student["id"];

$stmt = $conn->prepare(
    "SELECT internships.*, companies.company_name
    FROM internships
    JOIN companies ON internships.company_id = companies.id
    WHERE internships.id = ?"
);
$stmt->bind_param("i", $internship_id);
$stmt->execute();
$internship = $stmt->get_result()->fetch_assoc();

$message = "";

if (!$internship) {
    die("Internship not found.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $check = $conn->prepare("SELECT id FROM applications WHERE student_id = ? AND internship_id = ?");
    $check->bind_param("ii", $student_id, $internship_id);
    $check->execute();

    if ($check->get_result()->num_rows > 0) {
        $message = "You have already applied for this internship.";
    } else {
        $apply = $conn->prepare(
            "INSERT INTO applications (student_id, internship_id, status)
            VALUES (?, ?, 'Applied')"
        );
        $apply->bind_param("ii", $student_id, $internship_id);
        $apply->execute();
        $message = "Application submitted successfully.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apply - Anu InternBridge</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <nav class="navbar">
        <a class="brand" href="dashboard.php">Anu Intern<span>Bridge</span></a>
        <div class="nav-links"><a href="internships.php">Internships</a><a href="applications.php">Applications</a><a href="../logout.php">Logout</a></div>
    </nav>

    <main class="container narrow">
        <div class="panel application-detail">
            <span class="status open">OPEN</span>
            <h1><?php echo htmlspecialchars($internship["title"]); ?></h1>
            <h3><?php echo htmlspecialchars($internship["company_name"]); ?></h3>
            <p><strong>Location:</strong> <?php echo htmlspecialchars($internship["location"]); ?></p>
            <p><strong>Skills:</strong> <?php echo htmlspecialchars($internship["skills"]); ?></p>
            <p><?php echo nl2br(htmlspecialchars($internship["description"])); ?></p>

            <?php if ($message != ""): ?>
                <div class="alert success"><?php echo htmlspecialchars($message); ?></div>
            <?php else: ?>
                <form method="POST">
                    <button class="button primary" type="submit">Apply Now</button>
                </form>
            <?php endif; ?>
        </div>
    </main>
</body>
</html>
