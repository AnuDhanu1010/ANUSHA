```php
<?php

$host = "db01.dbhost.dev";
$username = "user_455qsfpeq";
$password = "p455qsfpeq";
$database = "db_455qsfpeq";
$port = 5051;

mysqli_report(MYSQLI_REPORT_OFF);

$conn = new mysqli(
    $host,
    $username,
    $password,
    $database,
    $port
);

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");

// Connection successful
?>
```