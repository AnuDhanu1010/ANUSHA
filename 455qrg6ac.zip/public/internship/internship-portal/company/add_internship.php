<?php
session_start();
require_once "../config/database.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] != "company") {
    header("Location: ../login.php");
    exit();
}

$stmt = $conn->prepare("SELECT id FROM companies WHERE user_id = ?");
$stmt->bind_param("i", $_SESSION["user_id"]);
$stmt->execute();
$company = $stmt->get_result()->fetch_assoc();
$company_id = $company["id"];

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = trim($_POST["title"]);
    $description = trim($_POST["description"]);
    $location = trim($_POST["location"]);
    $skills = trim($_POST["skills"]);

    if ($title == "" || $description == "") {
        $message = "Please fill in the required fields.";
    } else {
        $insert = $conn->prepare(
            "INSERT INTO internships (company_id, title, description, location, skills, status)
            VALUES (?, ?, ?, ?, ?, 'Open')"
        );
        $insert->bind_param("issss", $company_id, $title, $description, $location, $skills);

        if ($insert->execute()) {
            header("Location: internships.php?added=1");
            exit();
        }

        $message = "Unable to add internship.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Internship - Anu InternBridge</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <nav class="navbar">
        <a class="brand" href="dashboard.php">Anu Intern<span>Bridge</span></a>
        <div class="nav-links"><a href="dashboard.php">Dashboard</a><a href="internships.php">My Internships</a><a href="applicants.php">Applicants</a><a href="../logout.php">Logout</a></div>
    </nav>

    <main class="container narrow">
        <div class="page-heading"><div><div class="badge">NEW OPPORTUNITY</div><h1>Add Internship</h1><p>Create a clear internship listing for students.</p></div></div>

        <?php if ($message != ""): ?><div class="alert error"><?php echo htmlspecialchars($message); ?></div><?php endif; ?>

        <form class="panel" method="POST">
            <label>Internship Title *</label>
            <input type="text" name="title" placeholder="e.g. Full Stack Developer Intern" required>

            <label>Description *</label>
            <textarea name="description" rows="6" placeholder="Describe the internship role..." required></textarea>

            <label>Location</label>
            <input type="text" name="location" placeholder="e.g. Salem / Remote">

            <label>Required Skills</label>
            <input type="text" name="skills" placeholder="PHP, MySQL, HTML, CSS">

            <button class="button primary" type="submit">Publish Internship</button>
        </form>
    </main>
</body>
</html>
