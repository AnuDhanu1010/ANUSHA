<?php
session_start();
require_once "config/database.php";

$message = "";

if (isset($_GET["registered"])) {
    $message = "Account created successfully. Please sign in.";
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST["email"]);
    $password = $_POST["password"];

    $stmt = $conn->prepare("SELECT id, name, email, password, role FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();

        if (password_verify($password, $user["password"])) {
            $_SESSION["user_id"] = $user["id"];
            $_SESSION["name"] = $user["name"];
            $_SESSION["role"] = $user["role"];

            if ($user["role"] == "student") {
                header("Location: student/dashboard.php");
            } else {
                header("Location: company/dashboard.php");
            }
            exit();
        }
    }

    $message = "Invalid email or password.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In - Anu InternBridge</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="auth-page">
    <div class="auth-box">
        <a class="brand center-brand" href="index.php">Anu Intern<span>Bridge</span></a>
        <h1>Welcome back</h1>
        <p class="auth-subtitle">Sign in to continue to your dashboard.</p>

        <?php if ($message != ""): ?>
            <div class="alert success"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

        <form method="POST">
            <label>Email</label>
            <input type="email" name="email" placeholder="Enter your email" required>

            <label>Password</label>
            <input type="password" name="password" placeholder="Enter your password" required>

            <button class="button primary full" type="submit">Sign In</button>
        </form>

        <p class="auth-bottom">New here? <a href="register.php">Create an account</a></p>
    </div>
</body>
</html>
